# Agent: Campaign Performance

## What it does
Tells the user which campaigns are working, which aren't, and where they should consider shifting spend.

## When to use it
- The user picked "Campaign Performance" from the menu.
- Or the user asks anything like "how are my campaigns doing," "what's working," "where should I spend more," "which campaigns are wasting money."

## How to run it

### 1. Load the user's config
Read `config.md` at the root of this folder for: app IDs, start_date / end_date (from "time window"), Geo codes (from "markets"), Media sources (from "channels"), **primary_kpi** (the headline metric), and **secondary_kpis** (the supporting metrics).

If only `primary_kpi` is set (older configs from before the multi-KPI change), treat `secondary_kpis` as empty — the agent still works.

### 2. Run the AppsFlyer MCP query (single call — respects rate limit)
Call `fetch_aggregated_data` with these parameters:

```
app_ids: [<the user's chosen app IDs>]
start_date: <from config>
end_date: <from config>
groupings: ["Media source", "Campaign"]
metrics: [
  {"metric_name": "Installs"},
  {"metric_name": "Cost"},
  <primary_kpi from config>,
  <each entry from secondary_kpis>
]
filters:
  - If the user specified countries: {"Geo": [<country codes>]}
  - If the user specified channels: {"Media source": [<media sources>]}
row_count: 25
sort_by_metrics: [{"metric_name": "Cost", "order": "desc"}]
```

Always include `Installs` and `Cost` even if the user didn't pick them — they're needed for context and the watch-list logic below. De-dupe if the user's primary or secondary KPIs already include them.

If the user picked **"Other / custom"** in the questionnaire, pass their custom metric name through as-is. If AppsFlyer returns an error for an unknown metric, surface it plainly and offer to swap in a close match.

### 3. Parse the response
- The response is a CSV. First columns are groupings (Media source, Campaign), then metrics.
- Metric column names follow the pattern `<metricID> <period> <aggregation-type> <source>`.
- **Percentages are decimals.** A retention rate of `0.34` means 34%.
- Check the metadata for any metric with `partial-data?: true` — if true for retention, surface this as a caveat.

### 4. Analyze
- **Rank by primary KPI** — top 3 and bottom 3 campaigns.
- **Cross-check against secondary KPIs** — for each of the top 3, note whether the secondary metrics also look good or whether the campaign is winning on one number while losing on another (e.g., great ROAS but poor retention). Same check for the bottom 3 in reverse: a campaign that looks weak on the primary may be carrying the portfolio on a secondary.
- Any campaign with cost > 10% of total but underperforming on the primary KPI (sub-1.0 ROAS, sub-portfolio retention, above-portfolio CPI — whichever applies) — flag as "wasted spend."
- If you have time-comparison data (separate prior-period query — only if the user wants it), highlight any campaign whose primary KPI shifted >20%.

### 5. Deliver the answer
Plain-English summary, under 200 words. **Lead with the primary KPI; weave in secondary KPIs to add nuance, not to crowd the headline.**
- **The headline** — one sentence, framed around the primary KPI: what's the big takeaway?
- **What's working** — top 3 campaigns, the primary-KPI numbers, plus a one-clause note on each campaign's secondary metrics ("great ROAS *and* D7 retention" vs. "great ROAS but D7 retention is weak").
- **What's not** — bottom 3, same structure: where they fall short on the primary, and whether any of them are saved by a strong secondary metric.
- **What I'd look at next** — one or two concrete suggestions, ideally calling out the most useful trade-off the user should know about.

A small table is fine if it adds clarity. Lead with the headline, not the table.

### 6. Build the live artifact (mandatory)
Call `mcp__cowork__create_artifact` with name **"Campaign Performance"**. The artifact should show:
- A bar chart of the top 10 campaigns by spend, color-coded by the **primary KPI** (green = good, red = poor). For ROAS use ≥1.0 as the threshold; for retention or conversion rate use the portfolio average; for CPI/CPA invert (lower is greener).
- A "watch list" table of the bottom 3 campaigns showing the primary KPI alongside every secondary KPI the user picked.
- Headline stats: total spend, total installs, blended **primary KPI**, plus blended values for each secondary KPI.
- A "Last refreshed" timestamp.

Wire `mcpTools` to include `fetch_aggregated_data` so the artifact's Reload button pulls fresh data.

### 7. Update the Performance Command Center
**Update — don't recreate.** Call `mcp__cowork__list_artifacts`, find the artifact named exactly `"Performance Command Center"`, and use `mcp__cowork__update_artifact` with that ID. Flip the Campaign Performance tile from ⬜ pending → ✅ active, replace its copy-prompt button with the headline stat (top campaign by primary KPI), and refresh the top-strip totals (total spend, total installs, blended primary KPI). **Never call `create_artifact` here** — that produces the "Performance Command Center V2" duplicate. See CLAUDE.md > Performance Command Center for the full build rule.

### 8. Offer next steps
- Offer to schedule this agent weekly (use `mcp__scheduled-tasks__create_scheduled_task` with cron `0 9 * * 1`).
- Offer to drill into any specific campaign the user asks about.
- Point to `examples/campaign-performance-example.md` for the richer form.

## Failure modes
- **Empty CSV / no campaign data:** Check `get_active_cost_integrations` — if most integrations are in problem states, the user's cost data is incomplete. Suggest widening the time window or reconnecting integrations.
- **Rate limit error:** Tell the user plainly. Don't retry automatically.
- **MCP errors:** Pause, tell the user plainly, offer to retry once.

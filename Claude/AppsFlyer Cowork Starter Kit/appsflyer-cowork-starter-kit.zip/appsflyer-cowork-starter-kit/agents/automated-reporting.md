# Agent: Automated Reporting

## What it does
Sets up a recurring performance marketing report that runs automatically and delivers itself to the user — daily, weekly, or whatever cadence they want.

## When to use it
- The user picked "Automated Reporting" from the menu.
- Or the user asks anything like "send me a weekly report," "I want a daily summary," "automate this," "ping me every Monday."

## How to run it

### 1. Load the user's config
Read `config.md` for: app IDs, Geo codes, Media sources, primary KPI, key events, alert destination.

### 2. Ask the user what cadence they want (use AskUserQuestion)
Call `AskUserQuestion`:

```
question: "How often should the recurring report run?"
header: "Cadence"
multiSelect: false
options:
  - label: "Daily at 8 AM"          description: "Best for high-velocity teams. Shorter and lighter on data."
  - label: "Weekly Monday 9 AM"     description: "Recommended starting point. Enough signal, not too much noise."
  - label: "Monthly, 1st of month"  description: "For exec-style roll-ups. Includes month-over-month deltas."
  - label: "Custom"                  description: "Pick a different day/time."
```

If Custom, ask one follow-up for the specific day/time.

### 3. Define the report contents
The report should be readable in under 60 seconds. Plain English, numbers grouped for skimming. The recurring job pulls fresh data from AppsFlyer MCP using **at most 2 calls** to stay well inside the rate limit:

**Call A — top-line + top/bottom campaigns** (single `fetch_aggregated_data`):
```
groupings: ["Media source", "Campaign"]
metrics: [
  {"metric_name": "Installs"},
  {"metric_name": "Cost"},
  {"metric_name": "<user's primary KPI>"},
  {"metric_name": "ROAS"}
]
filters: <user's Geo + Media source filters from config>
row_count: 25
sort_by_metrics: [{"metric_name": "Cost", "order": "desc"}]
start_date / end_date: <the cadence period>
```

**Call B — key event trend** (single `fetch_aggregated_data`, only if user is tracking events):
```
groupings: ["Date"]
metrics: [{"metric_name": "Count"}, {"metric_name": "Revenue"}]
in_app_event: [<one of user's key events>]
start_date / end_date: <the cadence period>
```

If multiple key events are tracked, rotate which event the report focuses on each week — don't fire one call per event.

### 4. Render the report
Structure:
- **Headline** — one sentence: what's the big takeaway this period?
- **Top line** — Spend, Installs, primary KPI, with trend arrow vs. prior equivalent period (you'll need a second pair of calls for the prior period — only if the cadence is weekly or longer; skip for daily to save rate-limit budget)
- **Top 3 campaigns this period** — name + key numbers
- **Bottom 3 campaigns this period** — name + key numbers
- **Event trend** — one-line summary of the chosen event
- **One-line takeaway** — concrete suggestion

### 5. Schedule it
Use `mcp__scheduled-tasks__create_scheduled_task`:
- **Cadence:** Translate the user's choice into a cron expression (weekly Monday 9am → `0 9 * * 1`; daily 8am → `0 8 * * *`; monthly first-of-month → `0 9 1 * *`).
- **Task prompt:** Reference this agent file and have it re-run with the same parameters.
- **Delivery destination:** Per `config.md` — email, Slack (using the relevant connector), or "show in Cowork next time."

### 6. Run it once now (preview)
Run the report once immediately so the user sees what they'll receive. Then confirm the schedule is set.

### 7. Build the live artifact (mandatory)
Call `mcp__cowork__create_artifact` with name **"Automated Report — <cadence>"**. The artifact should show:
- The latest rendered report (headline, top-line stats, top/bottom 3 campaigns, event trend, takeaway)
- The next scheduled run time
- A "View previous runs" section that grows over time

Wire `mcpTools` to include `fetch_aggregated_data` so the artifact's Reload button regenerates the latest period on demand.

### 8. Update the Performance Command Center
**Update — don't recreate.** Call `mcp__cowork__list_artifacts`, find the artifact named exactly `"Performance Command Center"`, and use `mcp__cowork__update_artifact` with that ID. Flip the Automated Reporting tile from ⬜ pending → ✅ active, replace its copy-prompt button with the active-state summary (cadence + destination, e.g. "Weekly · Monday 9:00 AM → email"), and add the schedule to the "What's Running Automatically" strip. **Never call `create_artifact` here** — that produces the "Performance Command Center V2" duplicate. See CLAUDE.md > Performance Command Center for the full build rule.

### 9. Offer next steps
- Offer to add additional reports at different cadences.
- Point to `examples/automated-reporting-example.md` for the polished form.

## Failure modes
- **Scheduled tasks tool unavailable:** Set up the report as an on-demand prompt the user can run any time, and tell them automation needs a follow-up.
- **Delivery destination unreachable:** Fall back to "show in Cowork next time" and let the user know.
- **Rate limit hit during the live preview:** Tell the user, schedule the recurring run anyway, and note that the preview will show up on the next cadence trigger.

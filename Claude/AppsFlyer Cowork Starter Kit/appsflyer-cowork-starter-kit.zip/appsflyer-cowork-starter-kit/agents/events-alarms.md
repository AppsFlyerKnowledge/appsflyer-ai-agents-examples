# Agent: Events Alarms

## What it does
Watches the user's in-app events for unusual drops or spikes and pings them when something looks off. Sets itself up to run every morning automatically.

## When to use it
- The user picked "Events Alarms" from the menu.
- Or the user asks anything like "tell me if something breaks," "alert me on drops," "watch my purchases," "notify me when X changes."

## How to run it

### 1. Load the user's config
Read `config.md` for: app IDs, time window, alert destination.

### 2. Discover the top 10 events (one MCP call)
Don't ask the user to type event names — they may not remember the exact strings. Pull the top 10 events by volume from the last 30 days:

```
fetch_aggregated_data(
  app_ids: [<user's app IDs>],
  start_date: <30 days ago>,
  end_date: <yesterday>,
  groupings: ["Event name"],
  metrics: [{"metric_name": "Count"}, {"metric_name": "Unique users"}, {"metric_name": "Revenue"}],
  row_count: 10,
  sort_by_metrics: [{"metric_name": "Count", "order": "desc"}]
)
```

Parse the result and keep, for each of the 10 events: **event name, daily-average count, daily-average unique users, daily-average revenue** (compute by dividing the 30-day totals by the number of days in the window). You'll display all four in the table in Step 3 so the user picks intelligently — and you'll need the revenue column to support the "Top 3 revenue events" bundle.

### 3. Ask which events to watch — show the full top 10, then bundle the choices
`AskUserQuestion` caps at 4 options, so a pure menu can't expose all 10. Instead, do this in two beats:

**3a. Display the full top 10 as a numbered table in chat.** This gives the user the whole picture before they pick. Format it like this (Markdown table, no bullets):

```
| # | Event              | Daily count | Unique users/day | Daily revenue |
|---|--------------------|-------------|------------------|---------------|
| 1 | af_purchase        | ~1,240      | ~890             | ~$3,420       |
| 2 | af_complete_reg    | ~980        | ~970             | —             |
| … | …                  | …           | …                | …             |
| 10| af_share           | ~45         | ~42              | —             |
```

Sort the table by daily count (descending — same order as the MCP response). Show `—` (em dash) for revenue when the event has no revenue. Flag any event with daily count <10 by appending `· low volume` to the row — these will produce noisy alarms.

**3b. Ask the user to pick a bundle.** Use `AskUserQuestion` with these four options (single-select, not multi-select):

```
question: "Which events should I watch for unusual drops or spikes? The top 10 are above."
header: "Pick events"
multiSelect: false
options:
  - label: "Top 3 by volume"        description: "The three biggest events by daily count — covers most apps."
  - label: "Top 3 revenue events"   description: "The three highest-revenue events. Best if you care about monetization signals."
  - label: "All 10"                  description: "Watch everything. More alerts, more coverage."
  - label: "Let me pick specific ones"  description: "Reply with the numbers from the table (e.g., 1, 3, 7)."
```

**Resolving the user's pick:**
- **Top 3 by volume** → events at rows 1, 2, 3 from the table.
- **Top 3 revenue events** → re-sort the same 10 events by Daily revenue (descending), take the top 3. If fewer than 3 events have revenue, take the ones that do and tell the user plainly ("Only 2 of your top 10 events have revenue, so I'll watch those.").
- **All 10** → all rows from the table. Warn the user once about alarm volume: "Watching all 10 will produce more alerts — you can scale back any time."
- **Let me pick specific ones** → the user replies with comma-separated numbers (e.g., `1, 3, 7`). Map each number back to the corresponding row in the table you displayed. If the user types event names instead of numbers, accept that too. If anything doesn't parse (typos, out-of-range numbers), echo what you understood and ask once for confirmation.

Default if the user skips entirely: **Top 3 by volume**.

### 4. Ask for thresholds — as a menu, not a number
Use `AskUserQuestion` (one question, single-select). Do **not** ask for a specific percentage — present these four options:

```
question: "How sensitive should the alerts be? Each event will alert if its daily count moves by more than this vs its 30-day baseline."
header: "Sensitivity"
multiSelect: false
options:
  - label: "Loud — alert on ±10% moves"     description: "Catches small wobbles. More alerts, less noise tolerance. Best for revenue events."
  - label: "Balanced — alert on ±20% moves" description: "Recommended starting point. Catches real drops without firing on day-to-day variance."
  - label: "Quiet — alert on ±30% moves"    description: "Only the big stuff. Fewer false alarms but you may miss medium dips."
  - label: "Custom"                          description: "Tell me your own number. You can change this any time."
```

If the user picks Custom, ask for a number (any value 5–60% is fine). The same threshold applies to both the high and low side (±X%).

Default if skipped: Balanced (±20%).

### 5. Establish the baseline (one call per chosen event)
For each event the user picked, fetch the daily series for the last 30 days. This is what the alarm compares against tomorrow.

```
fetch_aggregated_data(
  app_ids: [<user's app IDs>],
  start_date: <30 days ago>,
  end_date: <yesterday>,
  groupings: ["Date"],
  metrics: [{"metric_name": "Count"}, {"metric_name": "Unique users"}, {"metric_name": "Revenue"}],
  in_app_event: [<event name>],
  row_count: 31
)
```

From the daily Count series, compute and store: mean daily count, standard deviation, the user's chosen ± threshold band. Store these in `config.md` under `events_alarms_baselines:` so the scheduled run doesn't have to recompute.

### 6. Ask when the check should run, then schedule it
The check needs to run **daily** (the baseline math compares to a 30-day daily series — anything less frequent breaks the comparison). But the **time of day** and whether to include weekends should match the user's rhythm — alerts that fire at 3 AM don't get acted on. Ask with `AskUserQuestion` (single-select):

```
question: "When should I check your events each day? You'll see alerts at this time."
header: "Schedule"
multiSelect: false
options:
  - label: "Weekday mornings (9 AM, Mon–Fri)"  description: "Recommended starting point. Quiet inbox time, no weekend pings."
  - label: "Every morning (9 AM, daily)"        description: "Includes weekends — useful if you have weekend traffic patterns."
  - label: "End of weekday (6 PM, Mon–Fri)"     description: "Review-and-close-out rhythm. No weekend pings."
  - label: "Custom time"                         description: "Tell me a specific time and whether to include weekends."
```

Map the answer to cron:
- Weekday mornings → `0 9 * * 1-5`
- Every morning → `0 9 * * *`
- End of weekday → `0 18 * * 1-5`
- **Custom** → ask the user for a time (e.g., "8 AM" → hour 8, "7:30 PM" → hour 19, minute 30) and "Include weekends?" (yes → `* * *`, no → `* * 1-5`). Build cron as `<minute> <hour> * * <days>`.

Default if the user skips entirely: **weekday mornings at 9 AM** (`0 9 * * 1-5`).

Before scheduling, verify the alert destination is appropriate. Check `config.md > alert_destination`. If it is an email address, confirm with the user that it is an internal team address — not a personal email or external account — before creating the scheduled task: *"Alerts will include your event data. Just confirming [destination] is an internal team address?"* Accept their answer and proceed; do not block the flow.

Then confirm the schedule itself before creating it. Use `AskUserQuestion`:

```
question: "Ready to turn on automatic event monitoring? I'll check your events [human-readable schedule label] and alert you at [destination] if anything looks unusual."
header: "Confirm schedule"
multiSelect: false
options:
  - label: "Yes, turn it on"    description: "Start the automatic daily check now."
  - label: "Not yet"            description: "I'll skip scheduling for now — you can run the check manually any time."
```

If the user picks "Not yet," skip `create_scheduled_task`, save the alarm rules to `config.md` anyway, and offer to schedule it later. Do not proceed to scheduling without an explicit "Yes."

Then call `mcp__scheduled-tasks__create_scheduled_task` with the chosen cron and this task prompt:

> "Run the Events Alarms daily check. For each event in `config.md > watched_events`, fetch yesterday's count via `fetch_aggregated_data` and compare it to the stored baseline. If yesterday's value falls outside the threshold band, send an alert to the destination in `config.md > alert_destination`. Then update the Performance Command Center artifact."

Save both the cron expression **and** a human-readable label (e.g., `"Weekday mornings at 9 AM local"`) under `config.md > events_alarms_schedule` so the artifact and the rest of the agent can display the schedule accurately without re-parsing cron.

### 7. Build the live artifact (mandatory)
Call `mcp__cowork__create_artifact` with name **"Events Alarms"**. The artifact should show:
- The watched events list (event name, daily average, threshold band, status: ✅ in band / 🚨 alert)
- Yesterday's value next to each event
- The schedule ("Runs <human-readable label from `config.md > events_alarms_schedule`> → alerts to <destination>")
- A small sparkline per event using the 30-day daily series

Wire the artifact's `mcpTools` to include `fetch_aggregated_data` so it can refresh from the connector.

### 8. Run the check once now (preview)
Compare yesterday's value to the baseline for each watched event:
- **If nothing trips:** "All your watched events look normal — alarms are armed for your next scheduled run (<human-readable label from `config.md > events_alarms_schedule`>)."
- **If something trips:** Show the user exactly what the alert will look like, including the value, the expected range, and the contributing breakdown (re-query with `groupings: ["Geo"]` or `["Media source"]` **only if** a breach fires — never speculatively).

### 9. Verify the schedule actually fires (confidence check)
The schedule is set, but novices don't trust automation they haven't seen run. Walk the user through proving it works before moving on. This takes <30 seconds and builds the wow moment.

Do this:
1. Confirm the task is registered: call `mcp__scheduled-tasks__list_scheduled_tasks` and locate the one you just created (it should be the most recent, matching the cron you set in Step 6). Note its ID and exact name so you can refer to them precisely.
2. Tell the user, in plain English, where to look and what to do. Use the actual task name from the list and the human-readable schedule label from `config.md`:

   > "I've scheduled the check to run **<schedule label>**, but let's prove it actually fires before we move on. Open Cowork's **Scheduled Tasks** panel (in the side menu), find the task called *'<actual task name>'*, and click **Run now**. It'll do exactly what your next scheduled run will do — same query, same comparison, same alert path. Let me know when it's done."

3. Wait for the user to come back. When they do, ask them to confirm two things: the task appeared in the list, and the output looks like the preview from Step 8 (same events, similar values). If both check out, say so clearly: "Great — your alarms are live. At your next scheduled run (<schedule label>) you'll get the same kind of summary automatically."
4. **If something's off** — task not listed, no "Run now" option, manual run produced an error or empty output — pause and troubleshoot:
   - Task not listed → the schedule didn't take. Recreate it (Step 6) and try again.
   - Manual run errored → re-read the error with the user. Most common cause is a stale baseline or an MCP rate limit. Re-run after a minute.
   - Output looks wrong → fall back to on-demand: tell the user you can run the check manually each morning instead of relying on the schedule, and offer to remove the scheduled task.

If the user wants to skip this verification ("I trust it, just continue"), respect that and move on — but flag in your next-steps offer (Step 11) that they can manually trigger a run any time from the Scheduled Tasks panel.

### 10. Update the Performance Command Center
**Update — don't recreate.** Call `mcp__cowork__list_artifacts`, find the artifact named exactly `"Performance Command Center"`, and use `mcp__cowork__update_artifact` with that ID. Flip the Events Alarms tile from ⬜ pending → ✅ active, replace its copy-prompt button with the active-state summary (e.g., "Watching 3 events · ±20% band"), and add the human-readable schedule label (from `config.md > events_alarms_schedule`) + alert destination to the "What's Running Automatically" strip. **Never call `create_artifact` here** — that produces the "Performance Command Center V2" duplicate. See CLAUDE.md > Performance Command Center for the full build rule.

### 11. Offer next steps
- Add more events to the watch list (re-runs Step 3 with events 5–10).
- Change sensitivity (re-runs Step 4).
- Trigger the daily check manually any time from the Scheduled Tasks panel.
- Point to `examples/events-alarms-example.md` for the polished alert format.

## Failure modes
- **Sparse event data:** If daily count is <10 on average, the baseline math is noisy. Flag it in the menu (label that event as "low volume — alarms may be noisy") and let the user decide.
- **Scheduled tasks tool unavailable:** Save the alarm rules to `config.md` and offer to run the check on demand. Tell the user the auto-schedule didn't take.
- **Rate limit hit during baseline setup:** Pause, tell the user, resume after the minute window. Don't retry blindly.

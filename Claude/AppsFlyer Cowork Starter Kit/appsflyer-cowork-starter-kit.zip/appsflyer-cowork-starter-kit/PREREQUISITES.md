# One-Time Setup: Connecting AppsFlyer MCP to Cowork

You only need to do this once. After it's done, the 5-minute starter kit experience is ready to run.

## What is "AppsFlyer MCP"?
MCP (Model Context Protocol) is the bridge that lets Cowork talk to your AppsFlyer data securely. Once connected, Cowork can pull campaign metrics, cohort data, events, and more — without you copying anything by hand.

## What you'll need
- An **AppsFlyer account** with access to the data you want to analyze
- The **AppsFlyer login you normally use** (email + password, or your company SSO if your org uses one)
- **Cowork open** on your computer

No API tokens, no admin handoff — connecting uses the same sign-in flow you already use for AppsFlyer.

## Steps
1. In Cowork, open Settings → Connectors → Add Connector.
2. Choose **AppsFlyer MCP** from the list.
3. Click **Connect**. Cowork opens a browser window to the AppsFlyer sign-in page.
4. Sign in to AppsFlyer the way you normally do — email/password or SSO. If you're already signed in, AppsFlyer will skip straight to the authorize step.
5. On the AppsFlyer authorization screen, review what Cowork is asking for (read access to your campaign, cohort, and event data) and click **Authorize**.
6. AppsFlyer sends you back to Cowork. Cowork runs a quick check to confirm the connection is live — you'll see a green ✅ next to "AppsFlyer MCP" in your connector list.

## You're done
You can now close this file and open `README.md` to start the 5-minute experience.

## If you hit a snag
- **Authorize button greyed out:** Your AppsFlyer role may not have the permissions Cowork needs. Ask your AppsFlyer admin to grant you "API / Reporting" access (or have them connect on your behalf).
- **Browser window didn't open:** Allow pop-ups for Cowork and try **Connect** again.
- **Returned to Cowork but the connector still shows ⬜ pending:** Click **Connect** again — the OAuth handshake sometimes needs a second attempt if the browser closed too quickly.
- **SSO error / "user not provisioned":** Your AppsFlyer SSO setup may not include Cowork as an authorized app yet. Your AppsFlyer or IT admin can add it.
- **"AppsFlyer MCP not in the connector list":** You may need to install or enable the AppsFlyer connector first. Check Cowork's connector marketplace.
- **Other issues:** Tell Cowork what happened — it can help diagnose.

> **Note:** This is the *only* setup step. Once MCP is connected, you won't need to do it again.

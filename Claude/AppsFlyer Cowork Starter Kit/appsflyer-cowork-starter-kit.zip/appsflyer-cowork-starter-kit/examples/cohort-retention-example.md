# Example: Cohort & Retention

This is what the Cohort & Retention agent's output looks like. Yours will be tailored to your apps, channels, and time window.

---

**The headline:** Google UAC users are sticking — your Meta Broad cohorts are evaporating by day 7.

**Best-retaining sources**
- *Google UAC — Tier 1 Brand* — D1 62%, D7 34%, D30 21%
- *Organic — US* — D1 58%, D7 31%, D30 19%
- *Apple Search Ads — Brand Defense* — D1 64%, D7 33%, D30 18%

**Leakiest sources**
- *Meta — Broad — US iOS* — D1 41%, D7 8%, D30 2% (largest cohort, worst retention)
- *TikTok — Interest "Gaming"* — D1 38%, D7 6%, D30 1%

**Hidden gem**
- *Reddit Ads — US* — Small cohort (just 4,200 installs this period), but D7 retention of 29% — worth scaling cautiously.

**What I'd look at next**
- Meta Broad is consuming ~28% of your spend and producing some of the worst retention. Tighten audiences or pause.
- Test scaling Reddit by 50% to see if retention holds at higher volume.

---

*Want me to compare this period to last quarter? Or focus on a single channel? Just ask.*

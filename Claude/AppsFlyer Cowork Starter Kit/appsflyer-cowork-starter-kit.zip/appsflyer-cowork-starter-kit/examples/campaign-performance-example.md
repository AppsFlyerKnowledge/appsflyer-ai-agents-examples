# Example: Campaign Performance

This is what the Campaign Performance agent's output looks like in its richer form. Yours will be tailored to your apps, your time window, your KPI.

---

**The headline:** Your Meta US iOS campaigns are carrying the quarter, but your TikTok spend in the same market is leaking budget on two campaigns that look broken.

**What's working**
- *Meta — US iOS — Lookalike 1%* — CPI $2.41 (vs. $4.10 portfolio average), volume up 18% week-over-week
- *Google UAC — US iOS — Tier 1 Brand* — CPI $3.02, D7 retention 34% (best in the portfolio)
- *Apple Search Ads — US — Brand Defense* — CPI $1.18, small volume but consistent

**What's not**
- *TikTok — US iOS — Broad Targeting v3* — CPI $11.40 (3× portfolio average), D7 retention 4%
- *TikTok — US iOS — Interest "Gaming"* — CPI $8.90, spend up 40% week-over-week with no install lift
- *Meta — US iOS — Interest "Finance"* — CPI $7.80, retention crashed to 6% this week

**What changed**
- TikTok spend grew 40% this week with no corresponding install lift — worth checking with the channel manager.
- Apple Search Ads volume is unusually flat — may be capped by budget rather than performance.

**What I'd look at next**
- Pause or rebuild the two underperforming TikTok campaigns.
- Consider shifting that budget to Meta Lookalike 1%, which is still scaling well.

---

*Want me to drill into any of these? Just ask. Or I can schedule this to run every Monday morning so you have it waiting for you.*

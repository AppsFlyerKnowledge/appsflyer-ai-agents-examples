# Example: Events Alarms

This is what an Events Alarms agent alert looks like when something looks off. You'll only see one if a watched event breaches its threshold — quiet otherwise.

---

## ⚠️ Events Alarm — May 16

**Event:** `purchase`
**App:** com.example.myapp (iOS)
**What happened:** Purchase events dropped 47% yesterday vs. the 30-day average.

**The numbers**
- Yesterday: 412 purchases
- 30-day average: 780 purchases/day (±110)
- Day-over-day: -41% (508 → 412)

**Where the drop is concentrated**
- US iOS: -52% (the steepest drop, largest contributor)
- Other markets: roughly flat

**Possible explanations to check**
- A campaign that drives high-intent users was paused or hit budget cap.
- A pricing/paywall change in the iOS app shipped recently.
- An attribution or SDK issue (purchase events not firing).

**Suggested next step:** Check whether any iOS US campaign was paused yesterday, and confirm with engineering that the purchase event is still firing correctly.

---

*You can ask Cowork to investigate any of these explanations in detail. Or, if this looks like normal noise, tell it and it'll learn your tolerance.*

*Quiet days mean your alarms are working — you'll only hear from this agent when something actually looks unusual.*

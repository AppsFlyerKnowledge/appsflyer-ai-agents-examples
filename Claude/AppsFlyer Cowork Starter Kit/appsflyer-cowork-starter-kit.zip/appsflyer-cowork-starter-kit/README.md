# AppsFlyer Cowork Starter Kit

Welcome. This folder turns Cowork into a performance marketing assistant for your AppsFlyer data — in about five minutes, with no prior experience needed.

## What you'll get
- A short, plain-English conversation that learns what matters to you
- A live **Performance Command Center** dashboard that summarises agent setup, schedules, and your headline numbers in one place
- Four ready-to-run agents — each one builds its own live dashboard automatically:
  1. **Campaign Performance** — what's working, what's not, where to shift spend
  2. **Events Alarms** — get pinged when a key event drops or spikes (runs daily, automatically)
  3. **Cohort & Retention** — D1 / D7 / D30 retention by channel
  4. **Automated Reporting** — recurring performance marketing reports delivered on the schedule you pick

## How to use it
1. **Make sure AppsFlyer MCP is connected to Cowork.** If you haven't done that yet, open `PREREQUISITES.md` for a 2-minute walkthrough. (This step is the only thing standing between you and the 5-minute clock starting.)
2. **Open this folder as a project in Cowork.**
3. **Say hi.** Just type "hi" or "let's start" — Cowork will take it from there. It will run a short questionnaire, then offer to activate the four agents.

That's it. No prompt engineering, no jargon, no manuals.

## What's inside

| File / Folder | What it's for |
|---|---|
| `CLAUDE.md` | Tells Cowork how to greet you and guide you. You don't need to read it. |
| `PREREQUISITES.md` | One-time AppsFlyer MCP setup, only if you haven't done it yet. |
| `TASKS.md` | A small list of day-one things to try once your agents are running. |
| `questionnaire/` | The script Cowork runs to learn what you care about. |
| `agents/` | The four pre-built performance marketing agents (campaign performance, cohort & retention, automated reporting, events alarms). |
| `examples/` | What each agent's output looks like, so you know what's coming. |

## Need a hand?
If anything goes sideways, just tell Cowork what happened ("I got an error", "I'm not sure what to do here"). It can help you back on track.

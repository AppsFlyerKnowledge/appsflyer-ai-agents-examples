# One-Time Setup: Connecting AppsFlyer MCP to Cowork

You only need to do this once. After it's done, the 5-minute starter kit experience is ready to run.

## What is "AppsFlyer MCP"?
MCP (Model Context Protocol) is the bridge that lets Cowork talk to your AppsFlyer data securely. Once connected, Cowork can pull campaign metrics, cohort data, events, and more — without you copying anything by hand.

## What you'll need
- An **AppsFlyer account** with access to the data you want to analyze
- An **AppsFlyer API token** (your account admin can generate one if you don't have it)
- **Cowork open** on your computer

## Steps
1. In AppsFlyer, generate or copy your API token. (Account Settings → API Tokens. If you can't see this, ask your AppsFlyer admin.)
2. In Cowork, open Settings → Connectors → Add Connector.
3. Choose **AppsFlyer MCP** from the list.
4. Paste your API token where prompted.
5. Click Connect. Cowork will run a quick check to confirm it's working.

## You're done
You can now close this file and open `README.md` to start the 5-minute experience.

## If you hit a snag
- **"Token rejected" / "401 error":** Double-check the token has the right permissions in AppsFlyer. Re-copy and re-paste it (no extra spaces).
- **"AppsFlyer MCP not in the connector list":** You may need to install or enable the AppsFlyer connector first. Check Cowork's connector marketplace.
- **Other issues:** Tell Cowork what happened — it can help diagnose.

> **Note:** This is the *only* setup step. Once MCP is connected, you won't need to do it again.

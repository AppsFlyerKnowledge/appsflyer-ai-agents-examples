# Day-One Explorations

Once you've run through the questionnaire and tried at least one agent, here are some easy next things to ask Cowork. None of them require any new setup.

## Quick wins
- "Open the UA Command Center." (your live home dashboard — agents, schedules, headline numbers in one place)
- "Run all four agents on my data, one after the other."
- "Turn on Events Alarms — watch my top events and ping me daily if anything looks off."
- "Schedule the weekly UA report for Monday morning."

## Drill-down questions to try
- "Which of my campaigns has the worst retention?"
- "Compare this month to last month for my top channel."
- "What's the cheapest market I'm acquiring users in, and is retention good there?"
- "If I had $10K extra to spend this week, where would you put it?"

## Make it yours
- "Change my primary KPI to ROAS."
- "Add `level_complete` and `subscription_start` to the events I'm watching."
- "Make the weekly report a daily report instead."

## When you've seen enough
- "Show me what else AppsFlyer data can tell me that I haven't asked yet."
- "What would a more advanced version of this look like?"

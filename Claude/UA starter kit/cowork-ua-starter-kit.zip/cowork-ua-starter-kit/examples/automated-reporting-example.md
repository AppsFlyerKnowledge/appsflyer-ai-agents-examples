# Example: Automated Reporting (Weekly)

This is what your weekly UA report looks like once it's scheduled. It arrives in whatever destination you picked (email, Slack, or just Cowork) every Monday morning.

---

## Weekly UA Snapshot — Week of May 11–17

**Headline:** Spend flat, installs down 6%, but D7 retention ticked up — quality > quantity week.

**Top line**
- Spend: $148,200 (+1% WoW)
- Installs: 38,940 (-6% WoW)
- Blended CPI: $3.81 (+7% WoW)
- D7 retention: 22% (+2pp WoW)

**Top 3 campaigns this week**
1. Meta — US iOS — Lookalike 1% — $2.41 CPI, 4,800 installs
2. Google UAC — US iOS — Tier 1 Brand — $3.02 CPI, 3,100 installs
3. Apple Search Ads — US — Brand Defense — $1.18 CPI, 980 installs

**Bottom 3 campaigns this week**
1. TikTok — US iOS — Broad Targeting v3 — $11.40 CPI
2. TikTok — US iOS — Interest "Gaming" — $8.90 CPI
3. Meta — US iOS — Interest "Finance" — $7.80 CPI

**Event trend shifts (>20%)**
- *Purchase events* up 31% WoW — driven mostly by Google UAC Brand cohort.
- *Tutorial complete* down 24% WoW — worth investigating onboarding.

**One-line takeaway**
Cut the bottom-3 TikTok bleed, double down on Meta Lookalike 1% — and check why tutorial completion dropped.

---

*Want this in a different format or cadence? Just tell Cowork — it can adjust on the fly.*

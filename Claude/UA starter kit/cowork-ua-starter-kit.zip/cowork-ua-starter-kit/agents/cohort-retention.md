# Agent: Cohort & Retention

## What it does
Shows how the people the user acquired are sticking around, broken down by acquisition source.

## When to use it
- The user picked "Cohort & Retention" from the menu.
- Or the user asks anything like "how's retention," "are my users sticking," "which channel brings the best users," "are these installs any good."

## How to run it

### 1. Load the user's config
Read `config.md` for: app IDs, start_date / end_date, Geo codes, Media sources.

### 2. Run the AppsFlyer MCP query (single call)
Call `fetch_aggregated_data` with these parameters:

```
app_ids: [<user's chosen app IDs>]
start_date: <from config>
end_date: <from config>
groupings: ["Media source"]
metrics: [
  {"metric_name": "Installs"},
  {"metric_name": "Retention rate", "period": "1"},
  {"metric_name": "Retention rate", "period": "7"},
  {"metric_name": "Retention rate", "period": "30"}
]
filters:
  - If the user specified countries: {"Geo": [<country codes>]}
  - If the user specified channels: {"Media source": [<media sources>]}
row_count: 15
sort_by_metrics: [{"metric_name": "Installs", "order": "desc"}]
```

If the user also wants an LTV-style view, add `{"metric_name": "ARPU"}` or `{"metric_name": "Revenue per unique user"}` to the metrics list (still one call).

### 3. Parse the response
- Columns: `Media source`, then `Installs`, then three retention columns (D1, D7, D30).
- **Retention values are decimals.** `0.34` = 34%.
- Check metadata for `partial-data?: true` on any retention metric — likely true for D30 retention if any installs in the window are <30 days old. Surface as a caveat.

### 4. Analyze
- **Best-retaining sources:** channels with the highest D7 and D30 retention (look at both — a channel that's great at D1 but tanks by D7 is a different story than one that holds steady).
- **Leakiest sources:** channels with the largest gap between D1 and D7 retention.
- **Volume-vs-quality flag:** A channel that's a top-3 install volume source but a bottom-3 retention source is likely wasted spend.
- **Hidden gem:** A small-volume channel (under 10% of total installs) with retention above the portfolio average.

### 5. Deliver the answer
Plain-English summary, under 200 words:
- **The headline** — one sentence on overall retention health.
- **Best-retaining sources** — names + the actual D1/D7/D30 percentages.
- **Leakiest sources** — names + the percentages, with the volume-vs-quality flag if it applies.
- **Hidden gem** — if any.
- **What I'd look at next** — one or two concrete suggestions.

### 6. Build the live artifact (mandatory)
Call `mcp__cowork__create_artifact` with name **"Cohort & Retention"**. The artifact should show:
- A retention curve chart per channel (lines for D1 → D7 → D30 retention by Media source)
- A sortable table: channel, installs, D1, D7, D30, with the "leaky" gap (D1 − D7) highlighted in red
- A callout for any hidden gem (low-volume, high-retention channel)
- A "Last refreshed" timestamp

Wire `mcpTools` to include `fetch_aggregated_data`.

### 7. Update the UA Command Center
Flip the Cohort & Retention tile from ⬜ pending → ✅ active. Add the best-retaining channel to the dashboard's recommendations strip.

### 8. Offer next steps
- Offer to schedule monthly retention reviews.
- Offer to drill into any specific channel or compare to a prior period.
- Point to `examples/cohort-retention-example.md` for the richer form.

## Failure modes
- **Sparse cohort data:** If install counts are <100 for most channels, retention rates will be noisy. Say so plainly and suggest widening the window.
- **All retention metrics flagged `partial-data?: true`:** The window is too recent. Suggest shifting the window earlier by 30+ days.
- **MCP errors:** Pause, tell the user plainly, offer to retry once.

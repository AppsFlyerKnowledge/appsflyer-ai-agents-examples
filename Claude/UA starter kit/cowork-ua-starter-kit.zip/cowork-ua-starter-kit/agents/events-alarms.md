# Agent: Events Alarms

## What it does
Watches the user's in-app events for unusual drops or spikes and pings them when something looks off. Sets itself up to run every morning automatically.

## When to use it
- The user picked "Events Alarms" from the menu.
- Or the user asks anything like "tell me if something breaks," "alert me on drops," "watch my purchases," "notify me when X changes."

## How to run it

### 1. Load the user's config
Read `config.md` for: app IDs, time window, alert destination.

### 2. Discover the top 10 events (one MCP call)
Don't ask the user to type event names — they may not remember the exact strings. Pull the top 10 events by volume from the last 30 days:

```
fetch_aggregated_data(
  app_ids: [<user's app IDs>],
  start_date: <30 days ago>,
  end_date: <yesterday>,
  groupings: ["Event name"],
  metrics: [{"metric_name": "Count"}, {"metric_name": "Unique users"}, {"metric_name": "Revenue"}],
  row_count: 10,
  sort_by_metrics: [{"metric_name": "Count", "order": "desc"}]
)
```

Parse the result and keep the 10 event names plus their daily-average counts (you'll show those next to each option so the user picks intelligently).

### 3. Ask which events to watch — as a multi-select menu
Use `AskUserQuestion` with `multiSelect: true`:

```
question: "Which events should I watch for unusual drops or spikes?"
header: "Pick events"
multiSelect: true
options:
  - label: "<event_1>"   description: "~<avg/day> per day · <unique users>/day"
  - label: "<event_2>"   description: "~<avg/day> per day"
  - label: "<event_3>"   description: "~<avg/day> per day"
  - label: "<event_4>"   description: "~<avg/day> per day"
```

`AskUserQuestion` caps at 4 options, so present the **top 4 by volume first**. If the user wants more, immediately fire a second `AskUserQuestion` with events 5–8, then 9–10 if asked. This stays inside the tool's limits while still giving the user the full top 10.

Default if they pick none: the #1 event by volume.

### 4. Ask for thresholds — as a menu, not a number
Use `AskUserQuestion` (one question, single-select). Do **not** ask for a specific percentage — present these four options:

```
question: "How sensitive should the alerts be? Each event will alert if its daily count moves by more than this vs its 30-day baseline."
header: "Sensitivity"
multiSelect: false
options:
  - label: "Loud — alert on ±10% moves"     description: "Catches small wobbles. More alerts, less noise tolerance. Best for revenue events."
  - label: "Balanced — alert on ±20% moves" description: "Recommended starting point. Catches real drops without firing on day-to-day variance."
  - label: "Quiet — alert on ±30% moves"    description: "Only the big stuff. Fewer false alarms but you may miss medium dips."
  - label: "Custom"                          description: "Tell me your own number. You can change this any time."
```

If the user picks Custom, ask for a number (any value 5–60% is fine). The same threshold applies to both the high and low side (±X%).

Default if skipped: Balanced (±20%).

### 5. Establish the baseline (one call per chosen event)
For each event the user picked, fetch the daily series for the last 30 days. This is what the alarm compares against tomorrow.

```
fetch_aggregated_data(
  app_ids: [<user's app IDs>],
  start_date: <30 days ago>,
  end_date: <yesterday>,
  groupings: ["Date"],
  metrics: [{"metric_name": "Count"}, {"metric_name": "Unique users"}, {"metric_name": "Revenue"}],
  in_app_event: [<event name>],
  row_count: 31
)
```

From the daily Count series, compute and store: mean daily count, standard deviation, the user's chosen ± threshold band. Store these in `config.md` under `events_alarms_baselines:` so the scheduled run doesn't have to recompute.

### 6. Schedule the daily check (no extra asking)
Call `mcp__scheduled-tasks__create_scheduled_task` with cron `0 9 * * *` (daily 9am local). The task prompt should reference this file and have the agent re-run with the stored baselines:

> "Run the Events Alarms daily check. For each event in `config.md > watched_events`, fetch yesterday's count via `fetch_aggregated_data` and compare it to the stored baseline. If yesterday's value falls outside the threshold band, send an alert to the destination in `config.md > alert_destination`. Then update the UA Command Center artifact."

Do this without re-asking the user. They've already chosen the events and the threshold — that's enough.

### 7. Build the live artifact (mandatory)
Call `mcp__cowork__create_artifact` with name **"Events Alarms"**. The artifact should show:
- The watched events list (event name, daily average, threshold band, status: ✅ in band / 🚨 alert)
- Yesterday's value next to each event
- The schedule ("Runs daily at 9:00 AM → alerts to <destination>")
- A small sparkline per event using the 30-day daily series

Wire the artifact's `mcpTools` to include `fetch_aggregated_data` so it can refresh from the connector.

### 8. Run the check once now (preview)
Compare yesterday's value to the baseline for each watched event:
- **If nothing trips:** "All your watched events look normal — alarms are armed for tomorrow's 9am check."
- **If something trips:** Show the user exactly what the alert will look like, including the value, the expected range, and the contributing breakdown (re-query with `groupings: ["Geo"]` or `["Media source"]` **only if** a breach fires — never speculatively).

### 9. Update the UA Command Center
Flip the Events Alarms tile from ⬜ pending → ✅ active. Add the 9:00 AM schedule and the destination to the "What's Running Automatically" section.

### 10. Offer next steps
- Add more events to the watch list (re-runs Step 3 with events 5–10).
- Change sensitivity (re-runs Step 4).
- Point to `examples/events-alarms-example.md` for the polished alert format.

## Failure modes
- **Sparse event data:** If daily count is <10 on average, the baseline math is noisy. Flag it in the menu (label that event as "low volume — alarms may be noisy") and let the user decide.
- **Scheduled tasks tool unavailable:** Save the alarm rules to `config.md` and offer to run the check on demand. Tell the user the auto-schedule didn't take.
- **Rate limit hit during baseline setup:** Pause, tell the user, resume after the minute window. Don't retry blindly.

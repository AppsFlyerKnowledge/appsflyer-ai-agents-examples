# Agent: Campaign Performance

## What it does
Tells the user which campaigns are working, which aren't, and where they should consider shifting spend.

## When to use it
- The user picked "Campaign Performance" from the menu.
- Or the user asks anything like "how are my campaigns doing," "what's working," "where should I spend more," "which campaigns are wasting money."

## How to run it

### 1. Load the user's config
Read `config.md` at the root of this folder for: app IDs, start_date / end_date (from "time window"), Geo codes (from "markets"), Media sources (from "channels"), primary KPI.

### 2. Run the AppsFlyer MCP query (single call — respects rate limit)
Call `fetch_aggregated_data` with these parameters:

```
app_ids: [<the user's chosen app IDs>]
start_date: <from config>
end_date: <from config>
groupings: ["Media source", "Campaign"]
metrics: [
  {"metric_name": "Installs"},
  {"metric_name": "Cost"},
  {"metric_name": "eCPI"},
  {"metric_name": "ROAS"},
  {"metric_name": "Retention rate", "period": "7"}
]
filters:
  - If the user specified countries: {"Geo": [<country codes>]}
  - If the user specified channels: {"Media source": [<media sources>]}
row_count: 25
sort_by_metrics: [{"metric_name": "Cost", "order": "desc"}]
```

If the user's primary KPI is something other than the metrics above (e.g., ROI, ARPU), swap it in or add it.

### 3. Parse the response
- The response is a CSV. First columns are groupings (Media source, Campaign), then metrics.
- Metric column names follow the pattern `<metricID> <period> <aggregation-type> <source>`.
- **Percentages are decimals.** A retention rate of `0.34` means 34%.
- Check the metadata for any metric with `partial-data?: true` — if true for retention, surface this as a caveat.

### 4. Analyze
- Top 3 performing campaigns by the user's primary KPI.
- Bottom 3 underperformers by the same KPI.
- Any campaign with cost > 10% of total but with sub-portfolio retention or sub-1.0 ROAS — flag as "wasted spend."
- If you have time-comparison data (separate prior-period query — only if the user wants it), highlight any campaign whose primary KPI shifted >20%.

### 5. Deliver the answer
Plain-English summary, under 200 words:
- **The headline** — one sentence: what's the big takeaway?
- **What's working** — top 3 campaigns, the numbers, why they stand out
- **What's not** — bottom 3, the numbers, why they stand out
- **What I'd look at next** — one or two concrete suggestions

A small table is fine if it adds clarity. Lead with the headline, not the table.

### 6. Build the live artifact (mandatory)
Call `mcp__cowork__create_artifact` with name **"Campaign Performance"**. The artifact should show:
- A bar chart of the top 10 campaigns by spend, color-coded by ROAS (green ≥1.0, red <1.0)
- A "watch list" table of the bottom 3 campaigns with their KPI numbers
- Headline stats: total spend, total installs, blended ROAS, blended eCPI
- A "Last refreshed" timestamp

Wire `mcpTools` to include `fetch_aggregated_data` so the artifact's Reload button pulls fresh data.

### 7. Update the UA Command Center
Flip the Campaign Performance tile from ⬜ pending → ✅ active. Add headline stats to the dashboard's top strip.

### 8. Offer next steps
- Offer to schedule this agent weekly (use `mcp__scheduled-tasks__create_scheduled_task` with cron `0 9 * * 1`).
- Offer to drill into any specific campaign the user asks about.
- Point to `examples/campaign-performance-example.md` for the richer form.

## Failure modes
- **Empty CSV / no campaign data:** Check `get_active_cost_integrations` — if most integrations are in problem states, the user's cost data is incomplete. Suggest widening the time window or reconnecting integrations.
- **Rate limit error:** Tell the user plainly. Don't retry automatically.
- **MCP errors:** Pause, tell the user plainly, offer to retry once.

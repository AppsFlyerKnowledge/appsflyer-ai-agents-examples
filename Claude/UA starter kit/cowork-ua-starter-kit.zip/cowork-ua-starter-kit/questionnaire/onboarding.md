# Onboarding Questionnaire

This is the script Cowork follows in Step 3 of the flow. Ask one question at a time, conversationally. Capture answers and save them in a `config.md` file at the root of this folder so the agents can use them.

## Goals
- Take **under 2 minutes** total.
- Use plain English, no UA jargon unless the user uses it first.
- Accept reasonable defaults if the user doesn't know an answer.

## The questions (ask one at a time, in this order)

### 1. Which app do you want to focus on?
Use the app list returned by the Step 2 `get_apps` call. Show the user the names (not bundle IDs) and let them pick by name or number. Store the **bundle ID(s)** in config, since that's what `fetch_aggregated_data` expects.

- Default if skipped: the first pinned app (or only app, if there's only one).
- If the user has only one app: skip this question entirely.

### 2. What's the time window you usually look at?
Examples to offer: "last 7 days," "last 30 days," "last quarter."

Translate the user's answer into concrete `start_date` and `end_date` values (format: `yyyy-MM-dd`). Store both.

- Default if skipped: last 30 days (today minus 30 → yesterday).

### 3. Which markets matter most to you?
Ask for countries. If the user names countries by name, map them to two-letter ISO codes for the Geo filter (US, GB, DE, JP, etc.).

- Default if skipped: no Geo filter (all markets).

### 4. Which channels are you running?
Examples to offer: Meta (Facebook), Google, TikTok, Apple Search Ads, organic. The Media source names in AppsFlyer can be inconsistent (`"Facebook Ads"`, `"facebook"`, `"googleadwords_int"`). If you're not sure of the exact name, run a small `fetch_aggregated_data` query grouped by Media source first and let the user pick from the actual list.

- Default if skipped: no Media source filter (all channels).

### 5. What's your #1 KPI right now?
Map their answer to a metric name from the AppsFlyer enum:
- "CPI" → `eCPI`
- "ROAS" → `ROAS`
- "ROI" → `ROI`
- "Retention" → `Retention rate` with `period: "7"` (D7 by default; ask if they want a different window)
- "Install volume" → `Installs`
- "Revenue" / "Purchases" → `Revenue`
- "LTV" / "ARPU" → `ARPU`

- Default if skipped: `eCPI` + `Retention rate` (D7) — two of the most common.

### 6. Which key event(s) do you watch most closely?
These will be passed as `in_app_event` to `fetch_aggregated_data` later. Common defaults: `af_purchase`, `af_complete_registration`, `af_level_achieved`, `af_subscribe`. Accept whatever the user types — the agent will surface an error if the event doesn't exist in their data.

- Default if skipped: `af_purchase` (single event).

### 7. If something looks wrong, where should I alert you?
Examples: email, Slack, just show it in Cowork next time.

- Default if skipped: "show it in Cowork next time."

## After the questionnaire
- Briefly recap what you heard, in plain English ("Got it — focusing on [App], over the last [N] days, in [markets], watching [KPI] and [events], alerts to [destination].")
- Save answers to `config.md` in this folder. Suggested format:

```
app_ids: ["com.example.app"]
start_date: "2026-04-17"
end_date: "2026-05-16"
geo_codes: ["US", "GB"]
media_sources: ["Facebook Ads", "googleadwords_int"]
primary_kpi: {"metric_name": "eCPI"}
key_events: ["af_purchase"]
alert_destination: "cowork"
```

- Move to Step 4 (pre-flight data-quality check), then Step 5 (offer the agents).

## If the user gets impatient
If the user says anything like "just start," "skip this," "give me something now," accept all defaults and jump straight to the agents. They can refine later.
